using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour {

	//Vector2 mousePosOrigin;
	//Vector2 mouseCurrentPos;
	//Vector2 dragDisplacement;

	//void Update()
	//{
	//	if (Input.GetMouseButtonDown(0))
	//	{
	//		mousePosOrigin = Input.mousePosition;
	//		Debug.Log("Origin point for mouse set");
	//	}

	//	if (Input.GetMouseButton(0))
	//	{
	//		mouseCurrentPos = Input.mousePosition;

	//		dragDisplacement = mouseCurrentPos - mousePosOrigin;
	//		Debug.Log(dragDisplacement.y);

	//		if (dragDisplacement.y > 0)
	//		{
	//			transform.position = new Vector3(transform.position.x, transform.position.y - dragDisplacement.y * Time.deltaTime, transform.position.z);
	//		}
	//		if (dragDisplacement.y < 0)
	//			transform.position = new Vector3(transform.position.x, transform.position.y - dragDisplacement.y * Time.deltaTime, transform.position.z);
	//	}
	//}
}
